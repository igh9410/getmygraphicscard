use Java
db.getCollectionNames()

