package com.getmygraphicscard.subscriptionservice.enums;

public enum Role {
    ADMIN, USER
}
