package com.getmygraphicscard.subscriptionservice.service;

public interface EmailService {
    void sendMailToSubscribers();
}
