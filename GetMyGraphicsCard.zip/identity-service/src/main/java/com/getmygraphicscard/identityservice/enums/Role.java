package com.getmygraphicscard.identityservice.enums;

public enum Role {
    ADMIN, USER
}
